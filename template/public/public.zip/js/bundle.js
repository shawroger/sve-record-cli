
(function(l, r) { if (l.getElementById('livereloadscript')) return; r = l.createElement('script'); r.async = 1; r.src = '//' + (window.location.host || 'localhost').split(':')[0] + ':35729/livereload.js?snipver=1'; r.id = 'livereloadscript'; l.head.appendChild(r) })(window.document);
var app = (function () {
    'use strict';

    function noop() { }
    function add_location(element, file, line, column, char) {
        element.__svelte_meta = {
            loc: { file, line, column, char }
        };
    }
    function run(fn) {
        return fn();
    }
    function blank_object() {
        return Object.create(null);
    }
    function run_all(fns) {
        fns.forEach(run);
    }
    function is_function(thing) {
        return typeof thing === 'function';
    }
    function safe_not_equal(a, b) {
        return a != a ? b == b : a !== b || ((a && typeof a === 'object') || typeof a === 'function');
    }

    function append(target, node) {
        target.appendChild(node);
    }
    function insert(target, node, anchor) {
        target.insertBefore(node, anchor || null);
    }
    function detach(node) {
        node.parentNode.removeChild(node);
    }
    function element(name) {
        return document.createElement(name);
    }
    function text(data) {
        return document.createTextNode(data);
    }
    function space() {
        return text(' ');
    }
    function listen(node, event, handler, options) {
        node.addEventListener(event, handler, options);
        return () => node.removeEventListener(event, handler, options);
    }
    function attr(node, attribute, value) {
        if (value == null)
            node.removeAttribute(attribute);
        else
            node.setAttribute(attribute, value);
    }
    function children(element) {
        return Array.from(element.childNodes);
    }
    function set_style(node, key, value, important) {
        node.style.setProperty(key, value, important ? 'important' : '');
    }
    function toggle_class(element, name, toggle) {
        element.classList[toggle ? 'add' : 'remove'](name);
    }
    function custom_event(type, detail) {
        const e = document.createEvent('CustomEvent');
        e.initCustomEvent(type, false, false, detail);
        return e;
    }

    let current_component;
    function set_current_component(component) {
        current_component = component;
    }

    const dirty_components = [];
    const binding_callbacks = [];
    const render_callbacks = [];
    const flush_callbacks = [];
    const resolved_promise = Promise.resolve();
    let update_scheduled = false;
    function schedule_update() {
        if (!update_scheduled) {
            update_scheduled = true;
            resolved_promise.then(flush);
        }
    }
    function add_render_callback(fn) {
        render_callbacks.push(fn);
    }
    function flush() {
        const seen_callbacks = new Set();
        do {
            // first, call beforeUpdate functions
            // and update components
            while (dirty_components.length) {
                const component = dirty_components.shift();
                set_current_component(component);
                update(component.$$);
            }
            while (binding_callbacks.length)
                binding_callbacks.pop()();
            // then, once components are updated, call
            // afterUpdate functions. This may cause
            // subsequent updates...
            for (let i = 0; i < render_callbacks.length; i += 1) {
                const callback = render_callbacks[i];
                if (!seen_callbacks.has(callback)) {
                    callback();
                    // ...so guard against infinite loops
                    seen_callbacks.add(callback);
                }
            }
            render_callbacks.length = 0;
        } while (dirty_components.length);
        while (flush_callbacks.length) {
            flush_callbacks.pop()();
        }
        update_scheduled = false;
    }
    function update($$) {
        if ($$.fragment) {
            $$.update($$.dirty);
            run_all($$.before_update);
            $$.fragment.p($$.dirty, $$.ctx);
            $$.dirty = null;
            $$.after_update.forEach(add_render_callback);
        }
    }
    const outroing = new Set();
    let outros;
    function transition_in(block, local) {
        if (block && block.i) {
            outroing.delete(block);
            block.i(local);
        }
    }
    function transition_out(block, local, detach, callback) {
        if (block && block.o) {
            if (outroing.has(block))
                return;
            outroing.add(block);
            outros.c.push(() => {
                outroing.delete(block);
                if (callback) {
                    if (detach)
                        block.d(1);
                    callback();
                }
            });
            block.o(local);
        }
    }
    function mount_component(component, target, anchor) {
        const { fragment, on_mount, on_destroy, after_update } = component.$$;
        fragment.m(target, anchor);
        // onMount happens before the initial afterUpdate
        add_render_callback(() => {
            const new_on_destroy = on_mount.map(run).filter(is_function);
            if (on_destroy) {
                on_destroy.push(...new_on_destroy);
            }
            else {
                // Edge case - component was destroyed immediately,
                // most likely as a result of a binding initialising
                run_all(new_on_destroy);
            }
            component.$$.on_mount = [];
        });
        after_update.forEach(add_render_callback);
    }
    function destroy_component(component, detaching) {
        if (component.$$.fragment) {
            run_all(component.$$.on_destroy);
            component.$$.fragment.d(detaching);
            // TODO null out other refs, including component.$$ (but need to
            // preserve final state?)
            component.$$.on_destroy = component.$$.fragment = null;
            component.$$.ctx = {};
        }
    }
    function make_dirty(component, key) {
        if (!component.$$.dirty) {
            dirty_components.push(component);
            schedule_update();
            component.$$.dirty = blank_object();
        }
        component.$$.dirty[key] = true;
    }
    function init(component, options, instance, create_fragment, not_equal, prop_names) {
        const parent_component = current_component;
        set_current_component(component);
        const props = options.props || {};
        const $$ = component.$$ = {
            fragment: null,
            ctx: null,
            // state
            props: prop_names,
            update: noop,
            not_equal,
            bound: blank_object(),
            // lifecycle
            on_mount: [],
            on_destroy: [],
            before_update: [],
            after_update: [],
            context: new Map(parent_component ? parent_component.$$.context : []),
            // everything else
            callbacks: blank_object(),
            dirty: null
        };
        let ready = false;
        $$.ctx = instance
            ? instance(component, props, (key, ret, value = ret) => {
                if ($$.ctx && not_equal($$.ctx[key], $$.ctx[key] = value)) {
                    if ($$.bound[key])
                        $$.bound[key](value);
                    if (ready)
                        make_dirty(component, key);
                }
                return ret;
            })
            : props;
        $$.update();
        ready = true;
        run_all($$.before_update);
        $$.fragment = create_fragment($$.ctx);
        if (options.target) {
            if (options.hydrate) {
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                $$.fragment.l(children(options.target));
            }
            else {
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                $$.fragment.c();
            }
            if (options.intro)
                transition_in(component.$$.fragment);
            mount_component(component, options.target, options.anchor);
            flush();
        }
        set_current_component(parent_component);
    }
    class SvelteComponent {
        $destroy() {
            destroy_component(this, 1);
            this.$destroy = noop;
        }
        $on(type, callback) {
            const callbacks = (this.$$.callbacks[type] || (this.$$.callbacks[type] = []));
            callbacks.push(callback);
            return () => {
                const index = callbacks.indexOf(callback);
                if (index !== -1)
                    callbacks.splice(index, 1);
            };
        }
        $set() {
            // overridden by instance, if it has props
        }
    }

    function dispatch_dev(type, detail) {
        document.dispatchEvent(custom_event(type, detail));
    }
    function append_dev(target, node) {
        dispatch_dev("SvelteDOMInsert", { target, node });
        append(target, node);
    }
    function insert_dev(target, node, anchor) {
        dispatch_dev("SvelteDOMInsert", { target, node, anchor });
        insert(target, node, anchor);
    }
    function detach_dev(node) {
        dispatch_dev("SvelteDOMRemove", { node });
        detach(node);
    }
    function listen_dev(node, event, handler, options, has_prevent_default, has_stop_propagation) {
        const modifiers = options === true ? ["capture"] : options ? Array.from(Object.keys(options)) : [];
        if (has_prevent_default)
            modifiers.push('preventDefault');
        if (has_stop_propagation)
            modifiers.push('stopPropagation');
        dispatch_dev("SvelteDOMAddEventListener", { node, event, handler, modifiers });
        const dispose = listen(node, event, handler, options);
        return () => {
            dispatch_dev("SvelteDOMRemoveEventListener", { node, event, handler, modifiers });
            dispose();
        };
    }
    function attr_dev(node, attribute, value) {
        attr(node, attribute, value);
        if (value == null)
            dispatch_dev("SvelteDOMRemoveAttribute", { node, attribute });
        else
            dispatch_dev("SvelteDOMSetAttribute", { node, attribute, value });
    }
    class SvelteComponentDev extends SvelteComponent {
        constructor(options) {
            if (!options || (!options.target && !options.$$inline)) {
                throw new Error(`'target' is a required option`);
            }
            super();
        }
        $destroy() {
            super.$destroy();
            this.$destroy = () => {
                console.warn(`Component was already destroyed`); // eslint-disable-line no-console
            };
        }
    }

    /* src\nav.svelte generated by Svelte v3.12.1 */

    const file = "src\\nav.svelte";

    function create_fragment(ctx) {
    	var nav, a0, t1, button, span, t2, div, ul, li0, a1, t3_value = ctx.initLink[0].name + "", t3, t4, li1, a2, t5_value = ctx.initLink[1].name + "", t5;

    	const block = {
    		c: function create() {
    			nav = element("nav");
    			a0 = element("a");
    			a0.textContent = "Fomina";
    			t1 = space();
    			button = element("button");
    			span = element("span");
    			t2 = space();
    			div = element("div");
    			ul = element("ul");
    			li0 = element("li");
    			a1 = element("a");
    			t3 = text(t3_value);
    			t4 = space();
    			li1 = element("li");
    			a2 = element("a");
    			t5 = text(t5_value);
    			attr_dev(a0, "class", "navbar-brand");
    			attr_dev(a0, "href", "javascript:;");
    			add_location(a0, file, 17, 1, 240);
    			attr_dev(span, "class", "navbar-toggler-icon");
    			add_location(span, file, 19, 2, 402);
    			attr_dev(button, "class", "navbar-toggler");
    			attr_dev(button, "type", "button");
    			attr_dev(button, "data-toggle", "collapse");
    			attr_dev(button, "data-target", "#collapsibleNavbar");
    			add_location(button, file, 18, 1, 297);
    			attr_dev(a1, "class", "nav-link");
    			attr_dev(a1, "href", ctx.initLink[0].link);
    			add_location(a1, file, 25, 7, 585);
    			attr_dev(li0, "class", "nav-item");
    			add_location(li0, file, 24, 5, 555);
    			attr_dev(a2, "class", "nav-link");
    			attr_dev(a2, "href", ctx.initLink[1].link);
    			add_location(a2, file, 28, 6, 698);
    			attr_dev(li1, "class", "nav-item");
    			add_location(li1, file, 27, 4, 669);
    			attr_dev(ul, "class", "navbar-nav");
    			add_location(ul, file, 23, 2, 525);
    			attr_dev(div, "class", "collapse navbar-collapse");
    			attr_dev(div, "id", "collapsibleNavbar");
    			add_location(div, file, 22, 1, 460);
    			attr_dev(nav, "class", "navbar navbar-expand-lg navbar-dark bg-primary");
    			add_location(nav, file, 16, 0, 177);
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert_dev(target, nav, anchor);
    			append_dev(nav, a0);
    			append_dev(nav, t1);
    			append_dev(nav, button);
    			append_dev(button, span);
    			append_dev(nav, t2);
    			append_dev(nav, div);
    			append_dev(div, ul);
    			append_dev(ul, li0);
    			append_dev(li0, a1);
    			append_dev(a1, t3);
    			append_dev(ul, t4);
    			append_dev(ul, li1);
    			append_dev(li1, a2);
    			append_dev(a2, t5);
    		},

    		p: noop,
    		i: noop,
    		o: noop,

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach_dev(nav);
    			}
    		}
    	};
    	dispatch_dev("SvelteRegisterBlock", { block, id: create_fragment.name, type: "component", source: "", ctx });
    	return block;
    }

    function instance($$self) {
    	let initLink = [{
    		link: './',
    		name: 'Maro'
    	},{
    		link: './docs',
    		name: 'Karame'
    	}];

    	$$self.$capture_state = () => {
    		return {};
    	};

    	$$self.$inject_state = $$props => {
    		if ('initLink' in $$props) $$invalidate('initLink', initLink = $$props.initLink);
    	};

    	return { initLink };
    }

    class Nav extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance, create_fragment, safe_not_equal, []);
    		dispatch_dev("SvelteRegisterComponent", { component: this, tagName: "Nav", options, id: create_fragment.name });
    	}
    }

    /* src\main-logo.svelte generated by Svelte v3.12.1 */

    const file$1 = "src\\main-logo.svelte";

    function create_fragment$1(ctx) {
    	var center, br0, t0, img, t1, br1, t2, h1, dispose;

    	const block = {
    		c: function create() {
    			center = element("center");
    			br0 = element("br");
    			t0 = space();
    			img = element("img");
    			t1 = space();
    			br1 = element("br");
    			t2 = space();
    			h1 = element("h1");
    			h1.textContent = "Re Sella res Fomina";
    			add_location(br0, file$1, 43, 0, 599);
    			attr_dev(img, "class", "ctrl svelte-6uug7k");
    			attr_dev(img, "src", ctx.imgSrc);
    			toggle_class(img, "bindAniImgHover", ctx.hover);
    			add_location(img, file$1, 44, 0, 606);
    			add_location(br1, file$1, 51, 0, 750);
    			attr_dev(h1, "class", "display-4 svelte-6uug7k");
    			add_location(h1, file$1, 52, 0, 757);
    			add_location(center, file$1, 42, 0, 589);

    			dispose = [
    				listen_dev(img, "mousemove", ctx.mousemove_handler),
    				listen_dev(img, "mouseout", ctx.mouseout_handler)
    			];
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert_dev(target, center, anchor);
    			append_dev(center, br0);
    			append_dev(center, t0);
    			append_dev(center, img);
    			append_dev(center, t1);
    			append_dev(center, br1);
    			append_dev(center, t2);
    			append_dev(center, h1);
    		},

    		p: function update(changed, ctx) {
    			if (changed.hover) {
    				toggle_class(img, "bindAniImgHover", ctx.hover);
    			}
    		},

    		i: noop,
    		o: noop,

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach_dev(center);
    			}

    			run_all(dispose);
    		}
    	};
    	dispatch_dev("SvelteRegisterBlock", { block, id: create_fragment$1.name, type: "component", source: "", ctx });
    	return block;
    }

    function instance$1($$self, $$props, $$invalidate) {
    	let imgSrc = 'img/logo-radius.png?v='+Math.random();
    	let hover  = false;

    	const mousemove_handler = () => {$$invalidate('hover', hover = true);};

    	const mouseout_handler = () => {$$invalidate('hover', hover = false);};

    	$$self.$capture_state = () => {
    		return {};
    	};

    	$$self.$inject_state = $$props => {
    		if ('imgSrc' in $$props) $$invalidate('imgSrc', imgSrc = $$props.imgSrc);
    		if ('hover' in $$props) $$invalidate('hover', hover = $$props.hover);
    	};

    	return {
    		imgSrc,
    		hover,
    		mousemove_handler,
    		mouseout_handler
    	};
    }

    class Main_logo extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$1, create_fragment$1, safe_not_equal, []);
    		dispatch_dev("SvelteRegisterComponent", { component: this, tagName: "Main_logo", options, id: create_fragment$1.name });
    	}
    }

    /* src\main-content.svelte generated by Svelte v3.12.1 */

    const file$2 = "src\\main-content.svelte";

    function create_fragment$2(ctx) {
    	var div4, div3, center, br0, t0, br1, t1, div2, div1, div0, h5, t2_value = ctx.data.title + "", t2, t3, p, t4_value = ctx.data.text + "", t4, t5, a, t6;

    	const block = {
    		c: function create() {
    			div4 = element("div");
    			div3 = element("div");
    			center = element("center");
    			br0 = element("br");
    			t0 = space();
    			br1 = element("br");
    			t1 = space();
    			div2 = element("div");
    			div1 = element("div");
    			div0 = element("div");
    			h5 = element("h5");
    			t2 = text(t2_value);
    			t3 = space();
    			p = element("p");
    			t4 = text(t4_value);
    			t5 = space();
    			a = element("a");
    			t6 = text("Go to docs");
    			add_location(br0, file$2, 13, 4, 224);
    			add_location(br1, file$2, 14, 4, 235);
    			attr_dev(h5, "class", "card-title");
    			add_location(h5, file$2, 18, 7, 361);
    			attr_dev(p, "class", "card-text");
    			add_location(p, file$2, 19, 7, 410);
    			attr_dev(a, "href", ctx.data.href);
    			attr_dev(a, "class", "btn btn-primary");
    			add_location(a, file$2, 20, 7, 455);
    			attr_dev(div0, "class", "card-body");
    			add_location(div0, file$2, 17, 5, 329);
    			attr_dev(div1, "class", "card");
    			set_style(div1, "width", "90vw");
    			set_style(div1, "border", "0");
    			add_location(div1, file$2, 16, 5, 274);
    			attr_dev(div2, "class", "col-12 ");
    			add_location(div2, file$2, 15, 4, 246);
    			add_location(center, file$2, 12, 2, 210);
    			attr_dev(div3, "class", "row justify-content-center");
    			add_location(div3, file$2, 10, 0, 164);
    			attr_dev(div4, "class", "container");
    			add_location(div4, file$2, 9, 0, 139);
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert_dev(target, div4, anchor);
    			append_dev(div4, div3);
    			append_dev(div3, center);
    			append_dev(center, br0);
    			append_dev(center, t0);
    			append_dev(center, br1);
    			append_dev(center, t1);
    			append_dev(center, div2);
    			append_dev(div2, div1);
    			append_dev(div1, div0);
    			append_dev(div0, h5);
    			append_dev(h5, t2);
    			append_dev(div0, t3);
    			append_dev(div0, p);
    			append_dev(p, t4);
    			append_dev(div0, t5);
    			append_dev(div0, a);
    			append_dev(a, t6);
    		},

    		p: noop,
    		i: noop,
    		o: noop,

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach_dev(div4);
    			}
    		}
    	};
    	dispatch_dev("SvelteRegisterBlock", { block, id: create_fragment$2.name, type: "component", source: "", ctx });
    	return block;
    }

    function instance$2($$self) {
    	let data = {
    		title: 'Etron uta Fomina',
        text: 'a new language system for human',
        href:'./docs'
    	};

    	$$self.$capture_state = () => {
    		return {};
    	};

    	$$self.$inject_state = $$props => {
    		if ('data' in $$props) $$invalidate('data', data = $$props.data);
    	};

    	return { data };
    }

    class Main_content extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$2, create_fragment$2, safe_not_equal, []);
    		dispatch_dev("SvelteRegisterComponent", { component: this, tagName: "Main_content", options, id: create_fragment$2.name });
    	}
    }

    /* src\App.svelte generated by Svelte v3.12.1 */

    function create_fragment$3(ctx) {
    	var t0, t1, current;

    	var nav = new Nav({ $$inline: true });

    	var mainlogo = new Main_logo({ $$inline: true });

    	var maincontent = new Main_content({ $$inline: true });

    	const block = {
    		c: function create() {
    			nav.$$.fragment.c();
    			t0 = space();
    			mainlogo.$$.fragment.c();
    			t1 = space();
    			maincontent.$$.fragment.c();
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			mount_component(nav, target, anchor);
    			insert_dev(target, t0, anchor);
    			mount_component(mainlogo, target, anchor);
    			insert_dev(target, t1, anchor);
    			mount_component(maincontent, target, anchor);
    			current = true;
    		},

    		p: noop,

    		i: function intro(local) {
    			if (current) return;
    			transition_in(nav.$$.fragment, local);

    			transition_in(mainlogo.$$.fragment, local);

    			transition_in(maincontent.$$.fragment, local);

    			current = true;
    		},

    		o: function outro(local) {
    			transition_out(nav.$$.fragment, local);
    			transition_out(mainlogo.$$.fragment, local);
    			transition_out(maincontent.$$.fragment, local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			destroy_component(nav, detaching);

    			if (detaching) {
    				detach_dev(t0);
    			}

    			destroy_component(mainlogo, detaching);

    			if (detaching) {
    				detach_dev(t1);
    			}

    			destroy_component(maincontent, detaching);
    		}
    	};
    	dispatch_dev("SvelteRegisterBlock", { block, id: create_fragment$3.name, type: "component", source: "", ctx });
    	return block;
    }

    class App extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, null, create_fragment$3, safe_not_equal, []);
    		dispatch_dev("SvelteRegisterComponent", { component: this, tagName: "App", options, id: create_fragment$3.name });
    	}
    }

    var app = new App({
    	target: document.body
    });

    return app;

}());
//# sourceMappingURL=bundle.js.map
